document.addEventListener('DOMContentLoaded', () => {
    const taskInput = document.getElementById('taskInput');
    const addTaskButton = document.getElementById('addTaskButton');
    const taskList = document.getElementById('taskList');

    addTaskButton.addEventListener('click', addTask);
    taskList.addEventListener('click', handleTaskActions);

    loadTasks();

    function addTask() {
        const taskText = taskInput.value.trim();
        if (taskText !== '') {
            const task = createTaskElement(taskText);
            taskList.appendChild(task);
            saveTasks();
            taskInput.value = '';
        }
    }

    function handleTaskActions(e) {
        if (e.target.classList.contains('delete')) {
            e.target.parentElement.remove();
            saveTasks();
        } else if (e.target.classList.contains('edit')) {
            const task = e.target.parentElement;
            const newTaskText = prompt('Edit your task:', task.querySelector('span').textContent);
            if (newTaskText !== null) {
                task.querySelector('span').textContent = newTaskText;
                saveTasks();
            }
        } else if (e.target.classList.contains('complete')) {
            e.target.parentElement.classList.toggle('completed');
            saveTasks();
        }
    }

    function createTaskElement(text) {
        const li = document.createElement('li');
        li.className = 'task';
        li.innerHTML = `
            <span>${text}</span>
            <button class="complete">Complete</button>
            <button class="edit">Edit</button>
            <button class="delete">Delete</button>
        `;
        return li;
    }

    function saveTasks() {
        const tasks = [];
        document.querySelectorAll('.task').forEach(task => {
            tasks.push({
                text: task.querySelector('span').textContent,
                completed: task.classList.contains('completed')
            });
        });
        localStorage.setItem('tasks', JSON.stringify(tasks));
    }

    function loadTasks() {
        const tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        tasks.forEach(task => {
            const taskElement = createTaskElement(task.text);
            if (task.completed) {
                taskElement.classList.add('completed');
            }
            taskList.appendChild(taskElement);
        });
    }
});
